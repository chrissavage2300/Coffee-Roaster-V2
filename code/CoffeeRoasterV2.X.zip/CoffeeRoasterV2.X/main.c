/**

        Product Revision  :  PIC24 / dsPIC33 / PIC32MM MCUs - 1.171.4
        Device            :  dsPIC33EP32MC204
    The generated drivers are tested against the following:
        Compiler          :  XC16 v2.10
        MPLAB 	          :  MPLAB X v6.05
*/

/*
 TO DO
 * 
 *
*/
#define FCY  7370000UL
#include <libpic30.h>
/**
  Section: Included Files
*/
#include "mcc_generated_files/system.h"
#include <stdio.h>
#include "mcc_generated_files/pin_manager.h"
#include "HD44780_I2C_lcd.h"
#include "mcc_generated_files/drivers/i2c_simple_master.h"
#include <stdbool.h>
#include "mcc_generated_files/pin_manager.h"
#include "mcc_generated_files/adc1.h"
//display defines
#define INIT_DELAY 50
#define DISPLAY_DELAY_2 2000
#define DISPLAY_DELAY 5000
//ADC  defines
//Start MCP3425 Defines
#define MCP3525_I2C_CLIENT_ADDR 0b1101000
#define MCP3525_DUMMY_REGISTER 0x00
#define MCP3525_12Bit_PGA1 0x90
#define MCP3525_14Bit_PGA1 0x94

#define MCP3525_16Bit_PGA1 0x98
#define MCP3525_16Bit_PGA2 0x99
#define MCP3525_16Bit_PGA4 0x9A//10011010, Channel 1 Contiuous conversion,16 bit,x4
#define MCP3525_16Bit_PGA4_Ch2 0xBA //10111010 channel 2, 16bit,x4
#define MCP3525_16Bit_PGA4_Ch4 0xFA //channel 4

#define MCP3525_16Bit_PGA8 0x9B

#define MCP3525_18Bit_PGA8 0x9F//channel 1,18 bit,x8. Max resolution.

//Temp Sensor Defines
//#define FLT_RADIX 10
#define MCP9800_I2C_CLIENT_ADDR 0b1001000 /* 7-bit address */
#define MCP9800_ReadTempAddress 0x00
#define MCP9800_REG_ADDR_CONFIG 0x01 // 0000 0001
#define MCP9800_REG_ADDR_TEMPERATURE 0x00
#define CONFIG_DATA_12BIT_RESOLUTION 0x60 //0110 0000
#define CONFIG_DATA_10BIT_RESOLUTION 0x20 //0010 0000
#define CONFIG_DATA_9BIT_RESOLUTION 0x00
const unsigned int MCP3525_ADC_Factor_16BPGA4_INT=156;

///
uint16_t ADCValue;
char LocalTemp[10];
char DrumSpeed[10];
char StringFanSpeed[10];
char String_TEMPERATURE_SP[10];
char String_TotalSeconds [10];
char String_FirstCrackDisplay[10];
char String_Thermocouple_ch1[14];
char String_FinalTime[10];
//
char DrumStartForLoop=0;
char StartPBForLoop=0;

bool FirstBoot=0;
bool DisplayRefresh=0;
bool DrumStarted=0;
bool RoasterStarted=0;
bool FirstCrackPB=0;
bool FirstCrackConfirmed=0;
bool FirstCrackEraseTime=0;
bool OvertempAlarm=0;
extern volatile bool RoasterStartedConfirmed;
//
unsigned int conversion,i=0,j=0,k=0,m=0;
unsigned int rawTempValue;
unsigned int rawtempc;
unsigned int scaledtempc;
//ADC Ints
unsigned int RawDrumSpeed;
unsigned int RawIntakeSpeed;
unsigned int ScaledDrumSpeed;
unsigned int ScaledIntakeSpeed;
unsigned int RawTEMP_SP;
unsigned int ScaledTempSP;
uint8_t adc3_resultBuff[3];
unsigned int adc3_result;
unsigned int ColdTempCompValue;

long MCP3425_ConvertedVoltage;
long CompensatedVoltage;//old float
long CompensatedVoltageIntermediate;
long FinaltempIntermediate;//old float
unsigned int FinalTemp_C;
unsigned int FinalTemp_F_Intermediate;
unsigned int FinalTemp_F;

//extern unsigned int TotalMiliSeconds;
unsigned int TotalSeconds=0;
unsigned int FirstCrackTime=0;
unsigned int FinalTime=0;
unsigned int FCHoldTime=0;

void Timer1UserInterrupt(void)
{  
  DisplayRefresh=1;//refresh display once per sec
  TEST_LED_Toggle();
}//InterruptHandler

void ADC_Read_DrumSpeed(void){//Drum is 0 to 66 RPM
    ADC1_Enable();
    ADC1_ChannelSelect(DRUM_SPEED);
    ADC1_SoftwareTriggerEnable();
    //Provide Delay
    for(i=0;i <1000;i++)
        {
        }
    ADC1_SoftwareTriggerDisable();
        while(!ADC1_IsConversionComplete(DRUM_SPEED));
    RawDrumSpeed = ADC1_ConversionResultGet(DRUM_SPEED);
    ADC1_Disable();
    //ScaledDrumSpeed=RawDrumSpeed;
    RawDrumSpeed=(RawDrumSpeed)/4;//Scale Drum speed to be 0 to 255 for PWM
     
    ScaledDrumSpeed=(RawDrumSpeed*100);
    ScaledDrumSpeed=(ScaledDrumSpeed/386);
    
}

void ADC_Read_IntakeFanSpeed(void){
    ADC1_Enable();
    ADC1_ChannelSelect(INTAKE_SPEED);
    ADC1_SoftwareTriggerEnable();
    //Provide Delay
    for(j=0;j <1000;j++)
        {
        }
    ADC1_SoftwareTriggerDisable();
        while(!ADC1_IsConversionComplete(INTAKE_SPEED));
    RawIntakeSpeed = ADC1_ConversionResultGet(INTAKE_SPEED);
    ADC1_Disable();
    
    RawIntakeSpeed=(RawIntakeSpeed)/4;//Scale intake  speed to be 0 to 255.
        
    ScaledIntakeSpeed=(RawIntakeSpeed*100);
    ScaledIntakeSpeed=ScaledIntakeSpeed/255;//scale 0 to 100%
}

void ADC_Read_Setpoint(void){//read setpoint pot. NOTE output is directly coupled to this.
    ADC1_Enable();
    ADC1_ChannelSelect(TEMP_SP);
    ADC1_SoftwareTriggerEnable();
    //Provide Delay
    for(k=0;k <1000;k++)
        {
        }
    ADC1_SoftwareTriggerDisable();
        while(!ADC1_IsConversionComplete(TEMP_SP));
    RawTEMP_SP = ADC1_ConversionResultGet(TEMP_SP);//0 to 1024
    ScaledTempSP=RawTEMP_SP;
    ADC1_Disable();
    RawTEMP_SP=RawTEMP_SP*30;//scale for Output compare.31000 max counts  
    ScaledTempSP=(ScaledTempSP*10);
    ScaledTempSP=(ScaledTempSP/102);
}



/*
                         Main application
 */
int main(void)
{
    // initialize the device
    SYSTEM_Initialize();
    TMR1_SetInterruptHandler(Timer1UserInterrupt);
    
    OC1_Stop();
    //OC2_Stop();
    //OC3_PrimaryValueSet(0);
    OC3_Stop();
        //set up I2C devices upon start up. We only need to do this once.
    i2c1_driver_driver_open();
    //First talk to the on board temp sensor.
    i2c_write1ByteRegister(MCP9800_I2C_CLIENT_ADDR, MCP9800_REG_ADDR_CONFIG, CONFIG_DATA_10BIT_RESOLUTION); 
    //talk to the ADC  next.
    i2c_write1ByteRegister(MCP3525_I2C_CLIENT_ADDR,MCP3525_16Bit_PGA4,MCP3525_16Bit_PGA4);
    
    __delay_ms(INIT_DELAY);
    PCF8574_LCDInit(LCDCursorTypeOff, 4, 20, 0x27);
    PCF8574_LCDClearScreenCmd(); 
    FirstBoot=1;
    while (1)
    {
         //so this sends out the address and the register we want to read from, in this case 0x00. We dont need to use the above
        //line first.        
        i2c_write1ByteRegister(MCP9800_I2C_CLIENT_ADDR,MCP9800_ReadTempAddress,0x00);
            
        rawTempValue=i2c_read2ByteRegister(MCP9800_I2C_CLIENT_ADDR,MCP9800_ReadTempAddress);
        //Remember the register that holds the temp has 4 leading 0's at the end
         rawtempc=rawTempValue>>6;
        //since we are in 10 bit mode (last bit is sign) we can shift over 6 bits
                
       scaledtempc=(rawtempc*100)/4;//this just makes it so we dont use floats.This takes 3.840us to complete.
         //MSB comes first so it would be buffer 0. LSB follows.
        //3rd byte is the config byte.
//read ADC
       i2c_readNBytes(MCP3525_I2C_CLIENT_ADDR,adc3_resultBuff,3);
        adc3_result = (adc3_resultBuff[0] << 8) | adc3_resultBuff[1];
       
//Start Thermocouple Calculation Sequence        
       //MCP3425_ConvertedVoltage=(adc3_result*MCP3525_ADC_Factor_16BPGA4_INT);//result is in uV*100
       MCP3425_ConvertedVoltage=__builtin_mulss(adc3_result,MCP3525_ADC_Factor_16BPGA4_INT);
       ColdTempCompValue=(scaledtempc*4);//convert measured cold junction temp to compensated k type. Scaling factor is x100
       CompensatedVoltage=MCP3425_ConvertedVoltage+ColdTempCompValue;
       CompensatedVoltageIntermediate=__builtin_divud (CompensatedVoltage,10);
       FinaltempIntermediate=__builtin_mulss(CompensatedVoltageIntermediate,24);
       FinalTemp_C=__builtin_divud (FinaltempIntermediate,1000);//55 cycles
       FinalTemp_F_Intermediate=__builtin_mulss(FinalTemp_C,18);//convert to F.F=temp*1.8+32.
       FinalTemp_F=FinalTemp_F_Intermediate+320;
       FinalTemp_F=__builtin_divud(FinalTemp_F,10);
               
       
//End thermocouple read sequence       
//ADC Read Sequences. These can go anywhere.       
       ADC_Read_DrumSpeed();
       ADC_Read_IntakeFanSpeed();
       ADC_Read_Setpoint();
       OC2_PrimaryValueSet(RawIntakeSpeed);//Intake fan PWM
       OC3_PrimaryValueSet(RawTEMP_SP);//set point is 0 to 100% essentially. 
//LCD PRINTS       
       sprintf(LocalTemp, "TEMP: %u%u/", (scaledtempc/1000)%10, (scaledtempc/100)%10); //(scaledtempc/10)%10, ( scaledtempc/1)%10);
       sprintf(DrumSpeed, "DRUM: %u%u%u",(ScaledDrumSpeed/100)%10,(ScaledDrumSpeed/10)%10, ( ScaledDrumSpeed/1)%10);
       sprintf(StringFanSpeed, "FAN: %u%u%u%", (ScaledIntakeSpeed/100)%10,(ScaledIntakeSpeed/10)%10, ( ScaledIntakeSpeed/1)%10); 
       sprintf(String_TEMPERATURE_SP, "P: %u%u%u%", (ScaledTempSP/100)%10,(ScaledTempSP/10)%10, ( ScaledTempSP/1)%10); 
       sprintf(String_TotalSeconds, "%u%u%u%u/",(TotalSeconds/1000)%10, (TotalSeconds/100)%10,(TotalSeconds/10)%10, ( TotalSeconds/1)%10);       
       sprintf(String_FirstCrackDisplay, "%u%u%u/", (FirstCrackTime/100)%10,(FirstCrackTime/10)%10, ( FirstCrackTime/1)%10);
       sprintf(String_Thermocouple_ch1,"TEMP: %u%u%u ", (FinalTemp_F/100)%10,(FinalTemp_F/10)%10, ( FinalTemp_F/1)%10);
       sprintf(String_FinalTime,"%u%u%u%u sec", (FinalTime/1000)%10,(FinalTime/100)%10,(FinalTime/10)%10, ( FinalTime/1)%10);
//Debounce Sequences//
//Drum Start Debounce Sequence       
       DrumStarted=DRUM_START_PB_GetValue();
       if (DrumStarted==0){//Debounce Loop NOTE WEAK PULL UPS
             for(DrumStartForLoop=0;DrumStartForLoop <10;DrumStartForLoop++)
             {//delay loop
               }//then check state to see if it settled  
             if (DRUM_START_PB_GetValue()==0){
                 OC1_Initialize();
                 OC1_PrimaryValueSet(RawDrumSpeed);}//Drum PWM}
        }//Debounce Loop
       else {OC1_Stop();}
       
//Start Roaster Debounce Sequence and Logic
       RoasterStarted=START_PB_GetValue();
       if (RoasterStarted==0)//WEAK PULL UPS, ZERO IS ON
        {
           for(StartPBForLoop=0;StartPBForLoop<10;StartPBForLoop++)
           {//delay loop
           }
           if (START_PB_GetValue()==0){//check to see if its still zero
            //OC2_Initialize();
            RoasterStartedConfirmed=0;
            }          
        }
            else{
                //OC2_PrimaryValueSet(0);
                //OC2_Stop();
                //OC3_PrimaryValueSet(0);
                OC3_Stop();
                RoasterStartedConfirmed=1;
                }//roaster start else logic     
//First Crack Debounce Sequence
       FirstCrackPB=FC_PB_GetValue();
       if (FirstCrackPB==0)
       { 
           for(m=0;m<1000;m++)
           {//delay loop
           }
           if (FC_PB_GetValue()==0){//check to see if its zero still
              FirstCrackConfirmed=0;               
              }
                   
       }//end First crack logic
        else{FirstCrackConfirmed=1;}    

//Debounce Sequences End//         
//First Crack Button Logic. Press button to record first crack.
       if (FirstCrackConfirmed==0){
        FirstCrackTime=TotalSeconds;
        FirstCrackEraseTime=1;
        
       }
FinalTime=FirstCrackTime+TotalSeconds;       

//overtemp alarm
if (FinalTemp_F>=470){OvertempAlarm=1;}
if (OvertempAlarm==1)
    {OvertempAlarm=0;
    OC3_Stop();//shut off roaster
    
    }
if (FinalTemp_F<470)
    {OvertempAlarm=0;   
    }


//LCD code
       
    if (DisplayRefresh==1){   //1 second interrupt code
        //things clear too fast so we use a one second delay to clear it. 
        if (FirstCrackEraseTime==1){
           TotalSeconds=0;
           FirstCrackEraseTime=0;
       }
        
        if (RoasterStartedConfirmed==0)//check to see if The roaster is started
        {
           TotalSeconds++;//increment time
           
           if (FirstCrackConfirmed==0){
               FCHoldTime++;

               
               if (FCHoldTime==5){//if we hold down the FC button for 5 seconds, do this next piece of code
                //TotalSeconds=0;
                //FirstCrackTime=0;
                FCHoldTime=0;
                FirstCrackConfirmed=1;
               }
               
           }       
     
        }
        else{//else if
            if (FirstCrackConfirmed==0){//if roaster is OFF and you press the FC button, this clears the timer
                TotalSeconds=0;
                FirstCrackTime=0;
            }
        
        }
//End Roaster Start Check logic for 1 second timer.         
         PCF8574_LCDGOTO(LCDLineNumberOne, 0);
         //PCF8574_LCDSendString("PV:000  T/FC:000/000");
         PCF8574_LCDSendString(String_Thermocouple_ch1);
         PCF8574_LCDSendString(String_TEMPERATURE_SP);
         
         PCF8574_LCDGOTO(LCDLineNumberTwo, 0);
         PCF8574_LCDSendString(String_TotalSeconds);
         PCF8574_LCDSendString(String_FirstCrackDisplay);
         PCF8574_LCDSendString(String_FinalTime);
         PCF8574_LCDGOTO(LCDLineNumberThree, 0);
         PCF8574_LCDSendString(DrumSpeed);
         PCF8574_LCDSendString("RPM");   
         PCF8574_LCDGOTO(LCDLineNumberFour, 0);
         PCF8574_LCDSendString(StringFanSpeed);
         DisplayRefresh=0;//end display refresh logic.
         //first boot clear. Clear after booting to make sure we show the correct data.
         if (FirstBoot==1){
             PCF8574_LCDClearScreenCmd();
             FirstBoot=0;
            }
        }//End Display Refresh Code
         //__delay_ms(DISPLAY_DELAY);
         //PCF8574_LCDClearScreenCmd();//this might not be needed
    }//main loop end
    return 1; 
}
/**
 End of File
*/

